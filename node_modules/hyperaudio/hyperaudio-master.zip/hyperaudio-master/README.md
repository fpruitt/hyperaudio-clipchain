hyperaudio
==========

Contains modules that will be useful as part of a hyperaudio.js library, used by developers to create applications.
