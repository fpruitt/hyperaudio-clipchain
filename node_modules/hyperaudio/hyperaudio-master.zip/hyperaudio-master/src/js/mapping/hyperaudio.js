hyperaudio.register('Music', Music);
hyperaudio.register('Player', Player);
hyperaudio.register('PlayerGUI', PlayerGUI);
hyperaudio.register('Transcript', Transcript);
hyperaudio.register('Stage', Stage);
hyperaudio.register('Projector', Projector);
