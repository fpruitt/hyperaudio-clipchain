	return hyperaudio;
}(window, document));
