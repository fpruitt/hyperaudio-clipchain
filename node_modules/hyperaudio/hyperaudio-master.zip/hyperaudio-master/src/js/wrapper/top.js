var HA = (function(window, document) {
